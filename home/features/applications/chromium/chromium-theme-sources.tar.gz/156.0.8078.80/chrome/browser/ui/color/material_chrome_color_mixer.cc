// Copyright 2023 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/ui/color/material_chrome_color_mixer.h"

#include "base/feature_list.h"
#include "chrome/browser/ui/color/chrome_color_id.h"
#include "chrome/browser/ui/color/chrome_color_provider_utils.h"
#include "chrome/browser/ui/ui_features.h"
#include "chrome/grit/theme_resources.h"
#include "components/compose/buildflags.h"
#include "ui/color/color_id.h"
#include "ui/color/color_mixer.h"
#include "ui/color/color_provider.h"
#include "ui/color/color_recipe.h"
#include "ui/color/color_transform.h"
#include "ui/gfx/color_palette.h"

namespace {

void ApplyDefaultChromeRefreshToolbarColors(ui::ColorMixer& mixer,
                                            const ui::ColorProviderKey& key) {
  mixer[kColorAppMenuHighlightDefault] = {
      kColorTabBackgroundInactiveFrameActive};
  mixer[kColorAppMenuExpandedForegroundDefault] = {
      kColorTabForegroundInactiveFrameActive};

  if (key.custom_theme && key.custom_theme->HasCustomImage(IDR_THEME_TOOLBAR)) {
    mixer[kColorAppMenuHighlightDefault] = {
        kColorToolbarBackgroundSubtleEmphasis};
    mixer[kColorAppMenuExpandedForegroundDefault] = {kColorToolbarButtonText};
  }

  mixer[kColorAppMenuHighlightSeverityLow] = {kColorAppMenuHighlightDefault};
  mixer[kColorAppMenuHighlightSeverityMedium] = {kColorAppMenuHighlightDefault};
  mixer[kColorAppMenuHighlightSeverityHigh] = {kColorAppMenuHighlightDefault};

  mixer[kColorAvatarButtonHighlightDefaultForeground] = {
      kColorAppMenuExpandedForegroundDefault};
  mixer[kColorAvatarButtonHighlightDefault] = {kColorAppMenuHighlightDefault};

  mixer[kColorAvatarButtonHighlightManagementForeground] = {
      kColorAvatarButtonHighlightDefaultForeground};
  mixer[kColorAvatarButtonHighlightManagement] = {
      kColorAvatarButtonHighlightDefault};
}

void ApplyChromeRefresh2026ColorOverrides(ui::ColorMixer& mixer) {
  if (!features::IsWebuiRefresh2026Enabled()) {
    return;
  }

  mixer[ui::kColorToolbarSearchFieldBackground] = {ui::kColorSysSurface4};
}

void ApplyChromeSettingsRefresh2026ColorOverrides(ui::ColorMixer& mixer) {
  if (!features::IsSettingsRefresh2026Enabled()) {
    return;
  }

  // Settings page colors.
  mixer[kColorSettingsWebuiPageBackground] = {ui::kColorSysSurface2};
  mixer[kColorSettingsTitleText] = {ui::kColorSysOnSurface};
  mixer[kColorSettingsSectionBackground] = {ui::kColorSysBase};
  mixer[kColorSettingsNavMenuItemBackground] = {ui::kColorSysTonalContainer};
  mixer[kColorSettingsNavMenuItemForeground] = {ui::kColorSysOnSurface};
  mixer[kColorSettingsNavMenuItemForegroundSelected] = {
      ui::kColorSysOnTonalContainer};
  mixer[kColorSettingsNavMenuItemIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorToolbarSearchFieldTextColor] = {ui::kColorSysOnSurfaceSubtle};
}

}  // namespace

void AddMaterialChromeColorMixer(ui::ColorProvider* provider,
                                 const ui::ColorProviderKey& key) {
  // Adds the color recipes for browser UI colors (toolbar, bookmarks bar,
  // downloads bar etc). While both design systems continue to exist, the
  // material recipes are intended to leverage the existing chrome color mixers,
  // overriding when required to do so according to the new material spec.
  // TODO(crbug.com/40888516): Update color recipes to match UX mocks.
  ui::ColorMixer& mixer = provider->AddMixer();

  // Apply default color transformations irrespective of whether a custom theme
  // is enabled. This is a necessary first pass with chrome refresh flag on to
  // make themes work with the feature.
  ApplyDefaultChromeRefreshToolbarColors(mixer, key);

  // Some colors in the material design should be applied regardless of whether
  // a custom theme is enabled.
  // TODO(tluk): Factor the always-applied material color definitions into a
  // separate file.

  // Content settings activity indicators popup dialog colors.
  mixer[kColorActivityIndicatorForeground] = {ui::kColorSysOnSurface};
  mixer[kColorActivityIndicatorSubtitleForeground] = {
      ui::kColorSysOnSurfaceSubtle};

  // Bookmark Manager page colors.
  mixer[kColorBookmarkManagerItemBackgroundSelected] = {
      ui::kColorSysBaseContainer};
  mixer[kColorBookmarkManagerItemOutline] = {ui::kColorSysPrimary};
  mixer[kColorBookmarkManagerItemText] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorBookmarkManagerItemTitle] = {ui::kColorSysOnSurface};

  // Desktop Media picker colors.
  mixer[kColorDesktopMediaPickerDescriptionLabel] = {
      ui::kColorSysOnSurfaceSubtle};

  // Desktop to iOS promo bubble colors.
  mixer[kColorDesktopToIOSPromoFooterSubtitleLabel] = {
      ui::kColorSysOnSurfaceSubtle};

  // Download bubble colors.
  mixer[kColorDownloadBubbleRowHover] = {ui::kColorSysStateHoverOnSubtle};
  mixer[kColorDownloadBubbleShowAllDownloadsIcon] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorDownloadBubbleInfoBackground] = {
      ui::kColorSubtleEmphasisBackground};
  mixer[kColorDownloadBubbleInfoIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorDownloadBubbleShowAllDownloadsIcon] = {ui::kColorIconSecondary};
  mixer[kColorDownloadBubblePrimaryIcon] = {ui::kColorSysPrimary};
  mixer[kColorDownloadToolbarButtonActive] = ui::PickGoogleColor(
      ui::kColorSysPrimary, kColorDownloadToolbarButtonRingBackground,
      color_utils::kMinimumVisibleContrastRatio);
  mixer[kColorDownloadToolbarButtonRingBackground] = {
      ui::kColorSysNeutralOutline};
  mixer[kColorDownloadToolbarButtonAnimationForeground] =
      AdjustHighlightColorForContrast(ui::kColorSysPrimary, ui::kColorSysBase);

  // Download History WebUI colors.
  mixer[kColorDownloadManagerItemError] = {ui::kColorSysError};
  mixer[kColorDownloadManagerItemBackground] = {ui::kColorSysSurface1};
  mixer[kColorDownloadManagerItemBackgroundInactive] = {
      ui::kColorSysStateDisabledContainer};
  mixer[kColorDownloadManagerProgress] = {ui::kColorSysPrimary};

  // General WebUI page colors.
  mixer[kColorWebuiCardBackground] = {ui::kColorSysSurfaceSection};
  mixer[kColorWebuiDialogBackground] = {ui::kColorSysSurface};
  mixer[kColorWebuiDialogContainerBackground] = {
      ui::kColorSysBaseContainerOnSurface};
  mixer[kColorWebuiPageBackground] = {ui::kColorSysSurface};

  // Nav menu item colors.
  mixer[kColorNavMenuItem] = {ui::kColorSysOnSurface};
  mixer[kColorNavMenuItemSelected] = {ui::kColorSysPrimary};
  mixer[kColorNavMenuItemBackgroundHover] = {ui::kColorSysStateHover};
  mixer[kColorNavMenuItemBackgroundSelected] = {ui::kColorSysBaseContainer};

  /* cr-tab colors. */
  mixer[kColorTabNavItemSelected] = {ui::kColorSysPrimary};

  // Extensions colors.
  mixer[kColorExtensionsMenuText] = {ui::kColorSysOnSurface};
  mixer[kColorExtensionsMenuSecondaryText] = {ui::kColorSysOnSurfaceSubtle};

  // Extension manager WebUI colors.
  mixer[kColorExtensionManagerHighlightText] = {ui::kColorSysPrimary};

  // Settings columned header colors.
  mixer[kColorSettingsColumnedSectionDescriptionHeader] = {
      ui::kColorSysPrimary};

  // Settings info card colors.
  mixer[kColorSettingsInfoCardBackground] = {ui::kColorSysBaseContainer};

  // Lens overlay colors.
  mixer[kColorLensOverlayToastBackground] = {ui::kColorSysInverseSurface};
  mixer[kColorLensOverlayToastButtonBorder] = {ui::kColorSysInverseOnSurface};
  mixer[kColorLensOverlayToastForeground] = {ui::kColorSysInverseOnSurface};

  // Glic selection overlay colors.
  // These must stay above the `ShouldApplyChromeMaterialOverrides()` guard
  // below, as the selection overlay preselection bubble is shown regardless of
  // whether a custom theme is installed, see b/562065771.
  mixer[kColorGlicSelectionOverlayToast] = {ui::kColorSysInverseSurfacePrimary};
  mixer[kColorGlicSelectionOverlayToastCancelButton] = {
      ui::kColorSysInversePrimary};

  // PageInfo colors.
  mixer[kColorPageInfoPermissionBlockedOnSystemLevelDisabled] = {
      ui::kColorSysStateDisabled};
  mixer[kColorPageInfoPermissionUsedIcon] = {ui::kColorSysPrimary};

  // Permission Prompt colors.
  mixer[kColorPermissionPromptRequestText] = {ui::kColorSysOnSurfaceSubtle};

  // Performance Intervention colors.
  mixer[kColorPerformanceInterventionButtonIconActive] =
      ui::PickGoogleColor(ui::kColorSysPrimary, ui::kColorSysNeutralOutline,
                          color_utils::kMinimumVisibleContrastRatio);
  mixer[kColorPerformanceInterventionButtonIconInactive] = {
      kColorToolbarButtonIcon};

  // Profile Menu colors.
  mixer[kColorProfileMenuBackground] = {ui::kColorSysSurface};
  mixer[kColorProfileMenuIdentityInfoBackground] = {ui::kColorSysSurface3};
  mixer[kColorProfileMenuIdentityInfoTitle] = {ui::kColorSysOnSurface};
  mixer[kColorProfileMenuIdentityInfoSubtitle] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorProfileMenuPromoButtonsBackground] = {
      ui::kColorSysTonalContainer};

  // App Menu colors.
  mixer[kColorAppMenuChipBackground] = {ui::kColorSysTonalContainer};
  mixer[kColorAppMenuChipBackgroundHovered] = {ui::GetResultingPaintColor(
      ui::kColorSysStateHoverOnSubtle, kColorAppMenuChipBackground)};
  mixer[kColorAppMenuChipForeground] = {ui::kColorSysOnTonalContainer};
  mixer[kColorAppMenuYourChromeBackground] = {ui::kColorSysBaseContainer};
  mixer[kColorAppMenuToolsAndActionsBackground] = {
      ui::kColorSysNeutralContainer};
  mixer[kColorAppMenuBlockButtonBackground] = {ui::kColorSysSurface};
  mixer[kColorAppMenuBlockButtonBackgroundHovered] = {
      ui::kColorSysStateHoverOnSubtle};
  mixer[kColorAppMenuBlockButtonBorder] = {ui::kColorSysInversePrimary};
  mixer[kColorAppMenuBlockButtonForeground] = {ui::kColorSysPrimary};
  mixer[kColorAppMenuFooterButtonForeground] = {ui::kColorSysPrimary};
  mixer[kColorAppMenuFooterButtonForegroundHovered] = {ui::kColorSysPrimary};
  mixer[kColorAppMenuFooterButtonBackgroundHovered] = {
      ui::kColorSysStateHoverOnSubtle};
  mixer[kColorAppMenuZoomButtonBackground] = {
      ui::kColorSysBaseContainerElevated};
  mixer[kColorAppMenuZoomButtonHover] = {ui::kColorSysStateHoverOnSubtle};
  mixer[kColorAppMenuZoomSeparator] = {ui::kColorSysNeutralOutline};

  // Signin bubble colors. Main background color uses the same color as the
  // profle menu background.
  mixer[kColorChromeSigninBubbleBackground] = {kColorProfileMenuBackground};
  mixer[kColorChromeSigninBubbleInfoBackground] = {ui::kColorSysSurface3};

  // Batch upload colors. Main background color uses the same color as the
  // profle menu background.
  mixer[kColorBatchUploadBackground] = {kColorProfileMenuBackground};
  mixer[kColorBatchUploadDataBackground] = {ui::kColorSysSurface3};
  mixer[kColorBatchUploadDataSeparator] = {ui::kColorSysOnHeaderDivider};

  // BNPL Issuer dialog color tokens
  mixer[kColorBnplIssuerLabelForeground] = {ui::kColorLabelForeground};
  mixer[kColorBnplIssuerLabelForegroundDisabled] = {
      ui::kColorLabelForegroundDisabled};
  mixer[kColorBnplIssuerLinkedIneligibleBackground] = {ui::kColorSysSurface2};
  mixer[kColorBnplIssuerLinkedPillBackground] = {ui::kColorBadgeBackground};
  mixer[kColorBnplIssuerLinkedPillForeground] = {ui::kColorBadgeForeground};
  mixer[kColorAutofillPopupDeactivatedBnplForeground] = ui::SetAlpha(
      ui::kColorLabelForegroundSecondary, gfx::kDisabledControlAlpha);

  // Tab Search colors.
  mixer[kColorTabSearchButtonBackground] = {ui::kColorSysSurface2};
  mixer[kColorTabSearchButtonIcon] = {ui::kColorSysOnTonalContainer};
  mixer[kColorTabSearchButtonIconBackground] = {ui::kColorSysTonalContainer};
  mixer[kColorTabSearchCardBackground] = {ui::kColorSysSurface3};
  mixer[kColorTabSearchBackground] = {ui::kColorSysSurface};
  mixer[kColorTabSearchDisabled] = {ui::kColorSysStateDisabled};
  mixer[kColorTabSearchDisabledContainer] = {
      ui::kColorSysStateDisabledContainer};
  mixer[kColorTabSearchDivider] = {ui::kColorSysDivider};
  mixer[kColorTabSearchFooterBackground] = {ui::kColorSysNeutralContainer};
  mixer[kColorTabSearchImageTabContentBottom] = {ui::kColorSysHeaderContainer};
  mixer[kColorTabSearchImageTabContentTop] = {ui::kColorSysOnPrimary};
  mixer[kColorTabSearchImageTabText] = {ui::kColorSysStateRipplePrimary};
  mixer[kColorTabSearchImageWindowFrame] = {ui::kColorSysInversePrimary};
  mixer[kColorTabSearchMediaIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorTabSearchMediaRecordingIcon] = {ui::kColorSysError};
  mixer[kColorTabSearchMediaGlicActiveIcon] = {ui::kColorSysPrimary};
  mixer[kColorTabSearchPrimaryForeground] = {ui::kColorSysOnSurface};
  mixer[kColorTabSearchSecondaryForeground] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorTabSearchSelected] = {ui::kColorSysPrimary};
  mixer[kColorTabSearchScrollbarThumb] = {ui::kColorSysPrimary};

  // Split View colors.
  mixer[kColorSplitViewBackground] = {ui::kColorSysSurface2};
  mixer[kColorMultiContentsViewMiniToolbarForeground] = {kColorToolbarText};

  // Slider colors.
  mixer[kColorSliderActive] = {ui::kColorSysPrimary};
  mixer[kColorSliderActiveContainer] = {ui::kColorSysDivider};
  mixer[kColorSliderActiveRipple] = {ui::kColorSysStateRipplePrimary};
  mixer[kColorSliderActiveText] = {ui::kColorSysOnPrimary};
  mixer[kColorSliderDisabled] = {ui::kColorSysNeutralOutline};
  mixer[kColorSliderDisabledContainer] = {ui::kColorSysSurfaceVariant};

  // Side Panel colors.
  mixer[kColorSidePanelBackground] = {ui::kColorSysBaseContainer};

  // Contextual Tasks Banner Promo colors.
  mixer[kColorContextualTasksBannerPromoBackground] = {
      ui::kColorSysBaseContainer};
  mixer[kColorContextualTasksBannerPromoText] = {ui::kColorSysOnSurface};
  mixer[kColorContextualTasksBannerPromoIconBackground] = {
      ui::kColorSysTonalContainer};

  // Read Anything (in the side panel) colors.
  mixer[kColorReadAnythingCurrentReadAloudHighlight] = {
      ui::kColorSysStateHoverOnSubtle};
  mixer[kColorReadAnythingForeground] = {ui::kColorSysOnSurface};
  mixer[kColorReadAnythingPreviousReadAloudHighlight] = {
      ui::kColorSysOnSurfaceSecondary};

  // Tab Group Dialog colors.
  mixer[kColorTabGroupDialogIconEnabled] = {ui::kColorSysOnSurfaceSubtle};

  // Cast Dialog colors.
  mixer[kColorCastDialogHelpIcon] = {ui::kColorSysPrimary};

  // Help bubble colors.
  mixer[kColorFeaturePromoBubbleBackground] = {ui::kColorSysPrimary};
  mixer[kColorFeaturePromoBubbleButtonBorder] = {
      kColorFeaturePromoBubbleForeground};
  mixer[kColorFeaturePromoBubbleCloseButtonInkDrop] =
      AdjustHighlightColorForContrast(kColorFeaturePromoBubbleForeground,
                                      kColorFeaturePromoBubbleBackground);
  mixer[kColorFeaturePromoBubbleDefaultButtonBackground] = {
      kColorFeaturePromoBubbleForeground};
  mixer[kColorFeaturePromoBubbleDefaultButtonForeground] = {
      kColorFeaturePromoBubbleBackground};
  mixer[kColorFeaturePromoBubbleForeground] = {ui::kColorSysOnPrimary};

  // Feature Showcase colors.
  mixer[kColorFeatureShowcaseStepperCheck] = {ui::kColorSysPrimary};
  mixer[kColorFeatureShowcaseStepperDot] = {ui::kColorSysPrimary};
  mixer[kColorFeatureShowcaseThemePickerWrapperBackground] = {
      ui::kColorSysSurface5};
  mixer[kColorFeatureShowcaseThemePickerBackground] = {ui::kColorSysSurface};
  mixer[kColorFeatureShowcaseThemeColorBorder] = {ui::kColorSysPrimary};

  // WebAuthn modal dialog colors.
  mixer[kColorWebAuthnBackArrowButtonIcon] = {ui::kColorSysPrimary};
  mixer[kColorWebAuthnBackArrowButtonIconDisabled] = {
      ui::kColorSysStateDisabled};
  mixer[kColorWebAuthnHoverButtonForeground] = {ui::kColorSysOnSurface};
  mixer[kColorWebAuthnHoverButtonForegroundDisabled] = {
      ui::kColorSysStateDisabled};
  mixer[kColorWebAuthnIconColor] = {ui::kColorSysPrimary};
  mixer[kColorWebAuthnIconColorDisabled] = {ui::kColorSysStateDisabled};
  mixer[kColorWebAuthnPinTextfieldBottomBorder] =
      PickGoogleColor(ui::kColorSysPrimary, ui::kColorSysSurface,
                      color_utils::kMinimumVisibleContrastRatio);
  mixer[kColorWebAuthnProgressRingBackground] = ui::SetAlpha(
      kColorWebAuthnProgressRingForeground, gfx::kGoogleGreyAlpha400);
  mixer[kColorWebAuthnProgressRingForeground] = {ui::kColorSysPrimary};

#if BUILDFLAG(ENABLE_COMPOSE)
  // Compose colors.
  mixer[kColorComposeDialogBackground] = {ui::kColorSysSurface};
  mixer[kColorComposeDialogDivider] = {ui::kColorSysDivider};
  mixer[kColorComposeDialogError] = {ui::kColorSysError};
  mixer[kColorComposeDialogForegroundSubtle] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorComposeDialogLink] = {ui::kColorSysPrimary};
  mixer[kColorComposeDialogLogo] = {ui::kColorSysOnTonalContainer};
  mixer[kColorComposeDialogScrollbarThumb] = {ui::kColorSysPrimary};
  mixer[kColorComposeDialogResultBackground] = {ui::kColorSysSurface5};
  mixer[kColorComposeDialogResultForeground] = {ui::kColorSysOnSurface};
  mixer[kColorComposeDialogResultForegroundWhileLoading] = {
      ui::kColorSysPrimary};
  mixer[kColorComposeDialogResultIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorComposeDialogResultContainerScrollbarThumb] = {
      ui::kColorSysTonalOutline};
  mixer[kColorComposeDialogTitle] = {ui::kColorSysOnSurface};
  mixer[kColorComposeDialogTextarea] = {ui::kColorSysOnSurface};
  mixer[kColorComposeDialogTextareaOutline] = {ui::kColorSysNeutralOutline};
  mixer[kColorComposeDialogTextareaPlaceholder] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorComposeDialogTextareaReadonlyBackground] = {
      ui::kColorSysNeutralContainer};
  mixer[kColorComposeDialogTextareaReadonlyForeground] = {
      ui::kColorSysOnSurface};
  mixer[kColorComposeDialogTextareaIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorComposeDialogSelectOptionDisabled] = {
      ui::kColorLabelForegroundDisabled};
#endif  // BUILDFLAG(ENABLE_COMPOSE)

  // History colors.
  mixer[kColorHistoryPageBookmarkStar] = {ui::kColorSysPrimary};
  mixer[kColorHistoryPageSeparator] = {ui::kColorSysSurfaceVariant};
  mixer[kColorHistoryPageText] = {ui::kColorSysOnSurfaceSubtle};

  // History Embeddings colors.
  mixer[kColorHistoryEmbeddingsBackground] = {
      ui::kColorSysBaseContainerElevated};
  mixer[kColorHistoryEmbeddingsDivider] = {ui::kColorSysDivider};
  mixer[kColorHistoryEmbeddingsForeground] = {ui::kColorSysOnSurface};
  mixer[kColorHistoryEmbeddingsForegroundSubtle] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorHistoryEmbeddingsImageBackground] = {
      ui::kColorSysNeutralContainer};
  mixer[kColorHistoryEmbeddingsImageBackgroundGradientEnd] = {
      ui::kColorSysGradientTertiary};
  mixer[kColorHistoryEmbeddingsImageBackgroundGradientStart] = {
      ui::kColorSysGradientPrimary};

  if (!ShouldApplyChromeMaterialOverrides(key)) {
    return;
  }

  mixer[kColorActorUiHandoffButtonBackground] = {ui::kColorSysSurface};
  mixer[kColorActorUiHandoffButtonBorder] = {ui::kColorSysActorUiBorder};
  mixer[kColorActorUiHandoffButtonForeground] = {ui::kColorSysOnSurface};
  mixer[kColorActorUiOverlayBorder] = {ui::kColorSysActorUiBorder};
  mixer[kColorActorUiOverlayBorderGlow] = {ui::kColorSysActorUiGradientEnd};
  mixer[kColorActorUiScrimStart] = {ui::kColorSysActorUiGradientStart};
  mixer[kColorActorUiScrimMiddle] = {ui::kColorSysActorUiGradientMiddle};
  mixer[kColorActorUiScrimEnd] = {ui::kColorSysActorUiGradientEnd};
  mixer[kColorActorUiMagicCursor] = {ui::kColorSysActorUiBorder};
  mixer[kColorAppMenuHighlightDefault] = {ui::kColorSysTonalContainer};
  mixer[kColorAppMenuHighlightSeverityLow] = {kColorAppMenuHighlightDefault};
  mixer[kColorAppMenuHighlightSeverityMedium] = {kColorAppMenuHighlightDefault};
  mixer[kColorAppMenuHighlightSeverityHigh] = {kColorAppMenuHighlightDefault};
  mixer[kColorAppMenuExpandedForegroundDefault] = {
      ui::kColorSysOnTonalContainer};
  mixer[kColorAppMenuChipInkDropHover] = {ui::kColorSysStateHoverOnSubtle};
  mixer[kColorAppMenuChipInkDropRipple] = {ui::kColorSysStateRipplePrimary};
  mixer[kColorAvatarButtonHighlightSyncPaused] = {
      kColorAvatarButtonHighlightDefault};
  mixer[kColorAvatarButtonHighlightPasskeysLocked] = {
      kColorAvatarButtonHighlightDefault};
  mixer[kColorAvatarButtonHighlightSigninPaused] = {
      kColorAvatarButtonHighlightDefault};
  mixer[kColorAvatarButtonHighlightSyncError] = {ui::kColorSysErrorContainer};
  mixer[kColorAvatarButtonHighlightIncognito] = {ui::kColorSysBaseContainer};
  mixer[kColorAvatarButtonHighlightGuestForeground] = {
      ui::kColorSysOnSurfaceSecondary};
  mixer[kColorAvatarButtonHighlightSyncErrorForeground] = {
      ui::kColorSysOnErrorContainer};
  mixer[kColorAvatarButtonHighlightIncognitoForeground] = {
      ui::kColorSysOnSurface};
  mixer[kColorAvatarButtonIncognitoHover] = {
      ui::kColorSysStateHoverBrightBlendProtection};
  mixer[kColorAvatarButtonNormalRipple] = {ui::kColorSysStateRipplePrimary};
  mixer[kColorBookmarkBarBackground] = {ui::kColorSysBase};
  mixer[kColorBookmarkBarForeground] = {ui::kColorSysOnSurfaceSubtle};
  // Aligns with kColorToolbarButtonIconInactive.
  mixer[kColorBookmarkBarForegroundDisabled] = {ui::GetResultingPaintColor(
      {ui::kColorSysStateDisabled}, {kColorToolbar})};
  mixer[kColorBookmarkBarSeparatorChromeRefresh] = {ui::kColorSysDivider};
  mixer[kColorBookmarkButtonIcon] = {kColorBookmarkBarForeground};
  mixer[kColorBookmarkDialogProductImageBorder] = {ui::kColorSysNeutralOutline};
  mixer[kColorBookmarkDialogTrackPriceIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorBookmarkDragImageBackground] = {ui::kColorSysPrimary};
  mixer[kColorBookmarkFolderIcon] = {kColorBookmarkBarForeground};
  mixer[kColorCapturedTabContentsBorder] = {ui::kColorSysPrimary};
  mixer[kColorDownloadItemIconDangerous] = {ui::kColorSysError};
  mixer[kColorDownloadItemIconWarning] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorDownloadItemTextDangerous] = {ui::kColorSysError};
  mixer[kColorDownloadItemTextWarning] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorExtensionIconBadgeBackgroundDefault] = {
      ui::kColorSysNeutralContainer};
  mixer[kColorFindBarBackground] = {ui::kColorSysSurface};
  mixer[kColorFlyingIndicatorBackground] = {kColorToolbar};
  mixer[kColorFlyingIndicatorForeground] = {kColorToolbarButtonIcon};
  mixer[kColorFrameCaptionActive] = {ui::kColorSysOnHeaderPrimary};
  mixer[kColorFrameCaptionInactive] = {ui::kColorSysOnHeaderPrimaryInactive};

  mixer[kColorTabHoverCardSecondaryText] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorInfoBarBackground] = {ui::kColorSysBase};
  mixer[kColorInfoBarButtonIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorInfoBarButtonIconDisabled] = {ui::kColorSysStateDisabled};
  mixer[kColorInfoBarForeground] = {ui::kColorSysOnSurface};
  mixer[ui::kColorInfoBarIcon] = {ui::kColorSysOnSurfaceSubtle};
  mixer[kColorMediaRouterIconActive] =
      ui::PickGoogleColor(ui::kColorSysPrimary, kColorToolbar,
                          color_utils::kMinimumVisibleContrastRatio);

  mixer[kColorMultiContentsViewMiniToolbarForeground] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorMultiContentsViewActiveContentOutline] = {ui::kColorSysOutline};
  mixer[kColorMultiContentsViewInactiveContentOutline] = {
      ui::kColorSysNeutralOutline};

  mixer[kColorNewTabButtonFocusRing] = ui::PickGoogleColorTwoBackgrounds(
      ui::kColorSysStateFocusRing,
      ui::GetResultingPaintColor(kColorNewTabButtonBackgroundFrameActive,
                                 ui::kColorFrameActive),
      ui::kColorFrameActive, color_utils::kMinimumVisibleContrastRatio);
  mixer[kColorNewTabButtonInkDropFrameActive] = {
      ui::kColorSysStateHoverOnSubtle};
  mixer[kColorNewTabButtonInkDropFrameInactive] = {
      kColorNewTabButtonInkDropFrameActive};

  // Omnibox chip colors.
  mixer[kColorOmniboxChipInUseActivityIndicatorBackground] = {
      ui::kColorSysPrimary};
  mixer[kColorOmniboxChipInUseActivityIndicatorForeground] = {
      ui::kColorSysOnPrimary};
  mixer[kColorOmniboxChipBackground] = {ui::kColorSysBaseContainerElevated};
  mixer[kColorOmniboxChipBlockedActivityIndicatorBackground] = {
      ui::kColorSysBaseContainerElevated};
  mixer[kColorOmniboxChipBlockedActivityIndicatorForeground] = {
      ui::kColorSysOnSurface};
  mixer[kColorOmniboxChipForegroundLowVisibility] = {ui::kColorSysOnSurface};
  mixer[kColorOmniboxChipForegroundNormalVisibility] = {ui::kColorSysPrimary};
  mixer[kColorOmniboxChipInkDropHover] = {
      ui::kColorSysStateHoverDimBlendProtection};
  mixer[kColorOmniboxChipInkDropRipple] = {
      ui::kColorSysStateRippleNeutralOnSubtle};
  mixer[kColorOmniboxChipOnSystemBlockedActivityIndicatorBackground] = {
      ui::kColorSysBaseContainerElevated};
  mixer[kColorOmniboxChipOnSystemBlockedActivityIndicatorForeground] = {
      ui::kColorSysError};

  // Tabstrip tab alert colors.
  mixer[kColorTabAlertAudioPlayingActiveFrameActive] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorTabAlertAudioPlayingActiveFrameInactive] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorTabAlertAudioPlayingInactiveFrameActive] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorTabAlertAudioPlayingInactiveFrameInactive] = {
      ui::kColorSysOnSurfaceSubtle};
  mixer[kColorTabAlertMediaRecordingActiveFrameActive] = {ui::kColorSysError};
  mixer[kColorTabAlertMediaRecordingActiveFrameInactive] = {ui::kColorSysError};
  mixer[kColorTabAlertMediaRecordingInactiveFrameActive] = {ui::kColorSysError};
  mixer[kColorTabAlertMediaRecordingInactiveFrameInactive] = {
      ui::kColorSysError};
  mixer[kColorTabAlertPipPlayingActiveFrameActive] = {ui::kColorSysPrimary};
  mixer[kColorTabAlertPipPlayingActiveFrameInactive] = {ui::kColorSysPrimary};
  mixer[kColorTabAlertPipPlayingInactiveFrameActive] = {ui::kColorSysPrimary};
  mixer[kColorTabAlertPipPlayingInactiveFrameInactive] = {ui::kColorSysPrimary};

  // Hover card tab alert colors.
  mixer[kColorHoverCardTabAlertMediaRecordingIcon] = {ui::kColorSysError};
  mixer[kColorHoverCardTabAlertPipPlayingIcon] = {ui::kColorSysPrimary};
  mixer[kColorHoverCardTabAlertAudioPlayingIcon] = {
      ui::kColorSysOnSurfaceSubtle};

  // Toolbar colors.
  mixer[kColorToolbar] = {ui::kColorSysBase};
  mixer[kColorToolbarButtonBackgroundHighlightedDefault] = {
      ui::kColorSysStateHoverOnSubtle};
  mixer[kColorToolbarButtonBorder] = {ui::kColorSysOutline};
  mixer[kColorToolbarButtonIcon] = {kColorToolbarButtonIconDefault};
  mixer[kColorToolbarButtonIconDefault] = {ui::kColorSysOnSurfaceSecondary};
  mixer[kColorToolbarButtonIconDisabled] = {ui::kColorSysStateDisabled};
  mixer[kColorToolbarButtonIconHovered] = {kColorToolbarButtonIcon};
  mixer[kColorToolbarButtonIconInactive] = {ui::GetResultingPaintColor(
      {ui::kColorSysStateDisabled}, {kColorToolbar})};
  mixer[kColorToolbarButtonIconPressed] = {kColorToolbarButtonIconHovered};
  mixer[kColorToolbarButtonText] = {ui::kColorSysOnSurfaceSecondary};
  mixer[kColorToolbarContentAreaSeparator] = {ui::kColorSysSurfaceVariant};
  mixer[kColorToolbarFeaturePromoHighlight] = {ui::kColorSysPrimary};
  mixer[kColorToolbarIconContainerBorder] = {ui::kColorSysNeutralOutline};
  mixer[kColorToolbarInkDropHover] = {ui::kColorSysStateHoverOnSubtle};
  mixer[kColorToolbarInkDropRipple] = {ui::kColorSysStateRippleNeutralOnSubtle};
  mixer[kColorToolbarExtensionSeparatorEnabled] = {ui::kColorSysDivider};
  mixer[kColorToolbarExtensionSeparatorDisabled] = {
      kColorToolbarButtonIconInactive};
  mixer[kColorToolbarSeparator] = {kColorToolbarSeparatorDefault};
  mixer[kColorToolbarSeparatorDefault] =
      ui::AlphaBlend(kColorToolbarButtonIcon, kColorToolbar, 0x3A);
  mixer[kColorToolbarText] = {kColorToolbarTextDefault};
  mixer[kColorToolbarTextDefault] = {ui::kColorSysOnSurfaceSecondary};
  mixer[kColorToolbarTextDisabled] = {kColorToolbarTextDisabledDefault};
  mixer[kColorToolbarTextDisabledDefault] = {ui::kColorSysStateDisabled};

  // Glic colors.
  mixer[kColorGlicActiveTabUnderlineGradient1] = {ui::kColorGlicTabUnderline1};
  mixer[kColorGlicActiveTabUnderlineGradient2] = {ui::kColorGlicTabUnderline2};
  mixer[kColorGlicActiveTabUnderlineGradient3] = {ui::kColorGlicTabUnderline3};
  mixer[kColorGlicInactiveTabUnderlineGradient1] = {
      ui::kColorGlicTabUnderline1};
  mixer[kColorGlicInactiveTabUnderlineGradient2] = {
      ui::kColorGlicTabUnderline2};
  mixer[kColorGlicInactiveTabUnderlineGradient3] = {
      ui::kColorGlicTabUnderline3};

  ApplyChromeRefresh2026ColorOverrides(mixer);
  ApplyChromeSettingsRefresh2026ColorOverrides(mixer);
}
